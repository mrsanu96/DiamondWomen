import React, { useState } from "react";

import { ethers } from "ethers";
import diaWomenABI from "./diaWomenAbi.json";
import bnbtest from "./bnbtest.json";
import BigNumber from "bignumber.js";
import * as s from '../../styles/globalStyles'
import {
  StyledButton,
  StyledImg,
  StyledLink,
  ResponsiveWrapper,
  StyledLogo,
  StyledRoundButton,
} from "./homestyle.js";
import './Home.css';

export const Home = () => {
  const [claimingNft, setClaimingNft] = useState(false);
  const [walletAddress, setwalletAdress] = useState(null);
  const [mintAmount, setMintAmount] = useState(1);
  const [mintedTokens, setmintedTokens] = useState(0);
  const [ready, setready] = useState(false);
  const [networkId, setnetworkId] = useState(null);

  const bnbCon = "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56";
  const womenCon = "0xef92b720279D797C4B4bDB5d0f201F77eDf13D88";

  async function connectMetamask() {
    if (typeof window.ethereum === "undefined") {
      throw new Error("Please install MetaMask to use this dApp!");
    }

    await window.ethereum.request({ method: "eth_requestAccounts" });

    const provider = new ethers.providers.Web3Provider(window.ethereum);

    const accounts = await provider.listAccounts();
    const address = accounts[0];

    const network = await provider.getNetwork();
    const networkId = network.chainId;

    const signer = provider.getSigner();
    if (networkId == "56") {
      const diaWomenContract = connectContract(womenCon, diaWomenABI, signer);
      console.log(diaWomenContract);

      const value = await diaWomenContract.totalSupply();
      const bigNum = new BigNumber(value._hex);
      const decimalValue = bigNum.toString(10);
      setmintedTokens(decimalValue);

      console.log(address, networkId);

      setwalletAdress(address);
      setnetworkId(networkId);
      setready(true);
    }
  }

  const decrementMintAmount = () => {
    let newMintAmount = mintAmount - 1;
    if (newMintAmount < 1) {
      newMintAmount = 1;
    }
    setMintAmount(newMintAmount);
  };

  const incrementMintAmount = () => {
    let newMintAmount = mintAmount + 1;
    if (newMintAmount > 5) {
      newMintAmount = 5;
    }
    setMintAmount(newMintAmount);
  };

  const mintToken = async () => {
    if (networkId == "56") {
      setClaimingNft(true);

      const provider = new ethers.providers.Web3Provider(
        window.ethereum,
        "any"
      );
      await provider.send("eth_requestAccounts", []);

      const signer = provider.getSigner();

      const bnbContract = connectContract(bnbCon, bnbtest, signer);
      console.log(bnbContract);

      const diaWomenContract = connectContract(womenCon, diaWomenABI, signer);
      console.log(diaWomenContract);

      let weiValue = new BigNumber(mintAmount * 10 * 10 ** 18);
      const tx = await bnbContract.approve(womenCon, weiValue.toString());
      await tx.wait();
      console.log(tx);

      const res_tx = await diaWomenContract.mint(mintAmount, {
        gasLimit: 430913,
      });

      await res_tx.wait();
      console.log(res_tx);
      setmintedTokens(parseInt(mintedTokens) + parseInt(mintAmount));
      setClaimingNft(false);
    }
  };

  const connectContract = (address, abi, signerOrProvider) => {
    return new ethers.Contract(address, abi, signerOrProvider);
  };

  return (
    <div className="home" id="home">
      <div className="homeleft">
        <img
          className="left-img"
          src="https://i.imgur.com/JsGCf9H.png"
          alt=""
        />
      </div>

      <div className="homeright">
        <h2 className="home-main-title">
          diamond <span style={{}}>woman</span>
        </h2>
        <p className="home-par">
          <span style={{}}>
            Limited time Community Growth Special: when prompted, set your BUSD
            approval limit to 10 BUSD or the approval will not succeed.{" "}
          </span>
          Only 1 mint is allowed per transaction. Prices are subject to rise.
          Each NFT will earn rewards from 20 #ROYALDBK tokens as well as a
          lottery ticket. Every 250 NFTs sold will give 5 randomly selected
          minters a 100 BUSD lottery prize.
        </p>
        <h2 className="home-short-item">
          {mintedTokens} / 9999{" "}
          <span style={{ color: "teal", fontWeight: "bold" }}>
            Diamond Women
          </span>{" "}
          MINTED
        </h2>
        {ready ? (
          <>
            <s.Container ai={"center"} jc={"center"} fd={"row"}>
              <StyledRoundButton
                style={{
                  lineHeight: 0.4,
                  color: "white",
                  backgroundColor: "#ffc700",
                }}
                disabled={claimingNft ? 1 : 0}
                onClick={(e) => {
                  e.preventDefault();
                  decrementMintAmount();
                }}
              >
                -
              </StyledRoundButton>
              <s.SpacerMedium />
              <s.TextDescription
                style={{
                  textAlign: "center",
                  color: "white",
                }}
              >
                {mintAmount}
              </s.TextDescription>
              <s.SpacerMedium />
              <StyledRoundButton
                style={{
                  lineHeight: 0.4,
                  color: "white",
                  backgroundColor: "#ffc700",
                }}
                disabled={claimingNft ? 1 : 0}
                onClick={(e) => {
                  e.preventDefault();
                  incrementMintAmount();
                }}
              >
                +
              </StyledRoundButton>
            </s.Container>
            <s.SpacerSmall />
            <s.Container ai={"center"} jc={"center"} fd={"row"}>
              <StyledButton
                disabled={claimingNft ? 1 : 0}
                onClick={(e) => {
                  e.preventDefault();
                  mintToken();
                }}
              >
                {claimingNft ? "BUSY" : "BUY"}
              </StyledButton>
            </s.Container>
          </>
        ) : (
          <>
            <input className="connect-txt" type="text" />
            <button
              className="connect-txtbtn"
              onClick={() => connectMetamask()}
            >
              connect
            </button>
          </>
        )}
      </div>
    </div>
  );
};
